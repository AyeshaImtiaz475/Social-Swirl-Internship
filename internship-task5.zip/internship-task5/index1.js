const myFunction = (a) => {
    console.log(`hello ${a}`);
};


module.exports = myFunction;