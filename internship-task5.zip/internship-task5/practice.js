var a= 10;
//var a =20;
//we can re-declare the value of the var 

let b = 20;
//let b = 30;
//let can be re-declare but cannot assign the value

const c=30;
//we cannot reassign the value in const 
console.log(a,b,c);

//template literal
//mostly we used let and const 
let fName = "Ayesha";
let lName = "Imtiaz";

//let fullName = fName+ " " + lName + 10 + 20;
let fullName = `My full Name is ${fName} ${lName} ${10 + 20}`;
console.log(fullName);

//arrow functions 
// function myFunction()
// {
//     console.log("Hello");
// }
// myFunction();

// let myFunction1 = () => {
//     console.log('hello everyone');
// };
// myFunction1();


// //rest and spread operator 
// const myFunction2 = (a1, ...b1) => {
//    console.log(a1);
//    //console.log(b1[2]);
//    console.log(b1[3])
// };
// myFunction2("Ayesha", 123, 23, 45, 67, 89);

// //spread operator
// let arr2= [123,4,5,67,89,66];
// let arr3 = [23,45,678];

// let newArray1 = [arr2,arr3, 12, 34, 54];
// console.log(newArray1)

// let arr= [123,4,5,67,89,66];
// let arr1 = [23,45,678];

// let newArray = [...arr, ...arr1, 12, 34, 54];
// console.log(newArray)


// let obj = {
//     name: "ayesha",
// };

// let newObj = {
//   ...obj,
//   age:21,
// };

// console.log(newObj);

//destructing array 
// let array = [2345,678,901, 556, 778];
// const [a1,b1,c1,d1,e1] = array;
// console.log(a1,b1,c1,d1,e1);

// let myObj = {
//    Name: 'foo',
//    category: 'foo',
// };

// const {Name, category} = myObj;
// console.log(Name);
// console.log(category);

//the function in which we pass it as the arugment into another function is called call back function

//aray method 
//map 
// let Array = [1,2,3,4,5,6,7];
// const myfunction = (value, index, Array) => {
//     console.log(value);
// };
// Array.map(myfunction);
//it return the new array at the end 

let myArray = [11,22,33,44,55,66,77];
// const FilterFunction = (value,index, array) => {
//      return value > 10;
// };
// let filtervalue = myArray.filter(FilterFunction);
// console.log(filtervalue);


//find -> return the single value 
// const Findfunction = (value , index, array) => {
//     return value > 10;
// };
// let value = myArray.find(Findfunction);
// console.log(value);

//reduce method 
let value = myArray.reduce((h1,h2) => {
     return h1 + h2;
});
console.log(value);


//modules
const myFunction = require('./index1.js');
myFunction("Ayesha");






