console.log("hello world");

//variables are the container and the data types are the items stored in it.
var myName;
myName = "Ayesha";
console.log(myName);

//Data types in js 
//primitive (Number, string, Boolean, symbol, null, undefined and BigInt) and 
//non-premitive data types (object, arrays)

var nullValue = null;
console.log(nullValue);
console.log(typeof nullValue);
//null value means neither 0 or 1 = typeof(object)
//in undefined you declare the value but don't assign the value

var undefinedValue;
console.log(undefinedValue);  //undefined 
console.log(typeof undefinedValue);  //undefined

//BigInt
var value = 99999999999999999999999999;
console.log(typeof value);

//string 
let x = 16 + " " + "Volvo";
console.log(x);

let y = "volvo" + 16 + 4;
console.log(y);

let carName1 = "Volvo XC60";
let carName2 = "Volvo XC60";
console.log(carName1 + " " + carName2);

//numbers 
let x1= 34.67;
let x2= 89.00; //it display 89.00 
console.log(x1 + " " + x2);

//exponential notation 
let p = 123e5; 
let q= 123e-5;
console.log(p + " " + q);

//BigInt 
let a = BigInt("12345678910111213141516");
console.log(a);

//boolean
let a1=5;
let b1 =6;
let z1 =6;
// console.log(a1 == b1);
// console.log(a1 == z1);
console.log(b1 == z1);


//Opeartors in js 
// Arithematic operator  -> +, -, *, /
//assignment operator   -> ==, =!, !, 
//conditional operator 
//logical operators

var a2= 10;
var b2 = 19;
var c2 = a2 + b2;
console.log(c2);

var myNumber = 100;
console.log(myNumber);

var a3 = 10;
var b3 = 20;
if(a3 > b3)
{
    console.log(a3 + " is greater than" + b3);
}
else{
    console.log(b3 + "greater than " + a3);
}


var s1 = 10;
var s2 = "10";

if( s1 == s2)
{
    console.log("hello");
}

//Logical operator : AND, NOT, OR 
var obj1 = 20;
var obj2 = 30;
if( obj1 > obj2 && obj1 < obj2) //all the conditions should be true
{
    console.log("hello, world");
}

var obj3 = 20;
var obj4 = 30;
if( obj3 > obj4 || obj3 < obj4) //all the conditions should be true
{
    console.log("hello, world");
}

var z3 = 30;
var z2 = 30;
if( z3 != z2 )
{
    console.log("Welcome to the web ");
}

//functions
function myFunction(a)
{
    console.log("Hello" + " " + a);
}
myFunction("ayesha");

//function2
function myfunction1(p1,p2)
{
    return p1 * p2;
}

let result = myfunction1(5,8);
console.log(result);

//function3
function toCelsius(f)
{
    return (5/9) * (f -32); 
}
let value1 = toCelsius(77);
console.log(value1);

//objects 
var user = {
    name: 'john',
    age: '20',
    location: true,
    hobbies: {
        first: "reading",
        second: "writing",
    },
};
console.log(user.hobbies.first);

var student ={
     firstName : "Ayesha",
     lastName : "Imtiaz",
      Myage :21,
      Institution: "LGU",
      Degree: "Software Engineering",
};
console.log(student.firstName + " " + student.lastName);

//arrays 
var arr= [1,2,3,44,55,6];
// console.log(arr);
console.log(arr[3]);
console.log(arr[2]);


const cars = ["saab", "volvo", "BMW"];
console.log(cars);
console.log(cars[0]);
cars[0] = "Opel";
console.log(cars);

const fruits = ["Banana", "Apple", "Mango", "Orange"];
console.log(fruits);

//loops 
const Cars = ["BMW", "Volvo", "Saab", "Ford", "Fiat", "Audi"];
let text = "";
for (let i=0; i<Cars.length; i++)
{
    text = text + Cars[i] + " ";
}
console.log(text);

//for loop
let t1 = " ";
for (let i=0; i<5; i++)
{
    t1 = t1 + "The number is " + i + " ";
}
console.log(t1);

// do while loop
var v1 = 0;
do {
    console.log(v1);
    v1++;
}
while(v1 <=10)


//while loop
var myvalue = 0;
while(myvalue <=10)
{
    myvalue++;
    console.log(myvalue);
}







