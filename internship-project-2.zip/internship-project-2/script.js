document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents the default form submission
    
    // Optionally perform form validation here
    
    // Redirect to index1.html
    window.location.href = 'index.html';
});




